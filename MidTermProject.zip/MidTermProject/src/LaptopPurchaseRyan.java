import java.util.Scanner;
/**  
* Abhishek Ryan - aryan9  
* CIS171 22149
* Feb 25, 2022  
*/
public class LaptopPurchaseRyan {
	//Main method
	public static void main(String[] args) {
		
		//creates a new Scanner object that allows the program to take in user input
		Scanner in = new Scanner(System.in);
		
		String programExit = "y"; //variable is declared & initialized and represents the sentinel value that is used to end the program
		String warrantyChoice = "n"; //variable is declared & initialized and represents the yes/no choice for adding the warranty
		String mouseChoice = "n"; //variable is declared & initialized and represents the yes/no choice for adding the wireless mouse
		
		//5 constant double variables declared & initialized and represents the price for each of the 5 laptops
		final double LAPTOP_PRICE_ONE = 1599.99;
		final double LAPTOP_PRICE_TWO = 799.99;
		final double LAPTOP_PRICE_THREE = 899.99;
		final double LAPTOP_PRICE_FOUR = 1549.99;
		final double LAPTOP_PRICE_FIVE = 2299.99;
		
		//5 constant string variables declared & initialized and represents the full descriptions for each of the 5 laptops
		final String LAPTOP_DESC_ONE = "ASUS - ROG Zephyrus 15.6\" QHD Gaming Laptop - AMD Ryzen 9 - 16GB Memory - NVIDIA GeForce RTX 3070 - 1TB SSD - Eclipse Grey";
		final String LAPTOP_DESC_TWO = "MSI - GF65 15.6\" 144hz Gaming Laptop - Intel Core i5 - NVIDIA GeForce RTX3060 - 512GB SSD - 8GB Memory - Black";
		final String LAPTOP_DESC_THREE = "Dell - G15 15.6\" FHD Gaming Laptop - AMD Ryzen 7 - 8GB Memory - NVIDIA GeForce RTX 3050 Ti Graphics - 512GB SSD - Phantom Grey";
		final String LAPTOP_DESC_FOUR = "ASUS - ROG Zephyrus M16 GU603 Gaming Laptop - Intel Core i9 - 16GB Memory - NVIDIA RTX3060 - 1TB SSD - Off Black";
		final String LAPTOP_DESC_FIVE= "Razer - Blade 15 Advanced - 15.6\" Gaming Laptop - QHD- 240HZ - Intel Core i7 - NVIDIA GeForce RTX 3060 - 16GB RAM - 1TB SSD - Black";
		
		//2 constant double variables that each represent the cost for the warranty and the wireless mouse
		final double WARRANTY_COST = 99.99;
		final double MOUSE_COST = 74.99;
		
		//4 prints statements that explain the functionality of the program to the user
		System.out.println("Hello! Welcome to Abhishek's Laptop Purchasing Program!");
		System.out.println("\nHere you can purchase high-end gaming laptops.");
		System.out.println("You can choose any laptop from a total of 5 different laptops with various price points and specs.");
		System.out.println("Along with a laptop you'll have the option of buying a 2 year protection warranty and an optional wireless mouse.");
		
		//prints message that tells the user to enter a word that will display all five laptops
		System.out.println("\nType 'display' to display all 5 laptops with their price and description: ");
		String displayLaptops = in.next().toLowerCase(); //takes and reads user input as a string and automatically sets the string to lower case
		
		//while loop that loops continously if the input from the user does not equal the string text 'display'
		//the loop exits once the user enters the correct word/string
		while(!displayLaptops.equals("display")) {			
			System.out.println("Invalid Input! Type 'display' to display all 5 laptops: "); //prints error message to the user for bad input
			displayLaptops = in.next().toLowerCase(); //takes and reads user input as a string and sets it to lower case
		}
		//print statements print all 5 laptops with their price, name, and description by calling the constant variables from lines 20 to 31
		System.out.println("---------------------------------------------------------");
		System.out.println("1: Price $" + LAPTOP_PRICE_ONE + " - " + LAPTOP_DESC_ONE);
		System.out.println("2: Price $" + LAPTOP_PRICE_TWO + " - " + LAPTOP_DESC_TWO);
		System.out.println("3: Price $" + LAPTOP_PRICE_THREE + " - " + LAPTOP_DESC_THREE);
		System.out.println("4: Price $" + LAPTOP_PRICE_FOUR + " - " + LAPTOP_DESC_FOUR);
		System.out.println("5: Price $" + LAPTOP_PRICE_FIVE + " - " + LAPTOP_DESC_FIVE);
		
	    //while loop that loops continuously as long as the user inputs "y" at the end of the program if they want to purchase more laptops, otherwise the program will end
		while(programExit.equalsIgnoreCase("y")) {
			//prints message to the user and prompts them to enter the laptop's product number in order to purchase a laptop
			System.out.println("\nTo purchase a laptop enter its product number '1', '2', '3', '4', or '5': ");
			String laptopChoice = in.next().toLowerCase(); //takes and reads user input as a string and sets it to lower case
			
			//nested while loop that continuously prompts the user to enter the laptop product number if the length of their input as a string is not equal to 1
			while(laptopChoice.length() != 1) {	
				//prints error message to the user for bad input
				System.out.println("Invalid Choice! To purchase a laptop enter its product number '1', '2', '3', '4', or '5: ");
				laptopChoice = in.next().toLowerCase(); //takes and reads user input as a string and sets it to lower case
			}
			double runningTotal = 0.0; //variable of data type double is set to 0 and is used to keep a running total or list that keeps track of the user's purchases
			boolean warrantyAdded = false; //variable of data type boolean that is set to false and represents whether or not the user chooses to add the optional warranty
			boolean mouseAdded = false; //variable of data type boolean that is set tot false and represents whether or not the user chooses to add the optional wireless mouse
			
			//if-else-if statement that tests if the laptopChoice from the user is equal to at least one of the 5 laptop options, otherwise an error message is displayed to the user
			if(laptopChoice.equals("1")) {
				System.out.println("Laptop 1 has been added to your subtotal."); //prints that the laptop has been added to their purchase
				runningTotal += LAPTOP_PRICE_ONE; //the cost of the laptop is added to the runningTotal variable
			}else if(laptopChoice.equals("2")) {
				System.out.println("Laptop 2 has been added to your subtotal."); //prints that the laptop has been added to their purchase
				runningTotal += LAPTOP_PRICE_TWO; //the cost of the laptop is added to the runningTotal variable
			}else if(laptopChoice.equals("3")) {
				System.out.println("Laptop 3 has been added to your subtotal."); //prints that the laptop has been added to their purchase
				runningTotal += LAPTOP_PRICE_THREE; //the cost of the laptop is added to the runningTotal variable
			}else if(laptopChoice.equals("4")) {
				System.out.println("Laptop 4 has been added to your subtotal."); //prints that the laptop has been added to their purchase
				runningTotal += LAPTOP_PRICE_FOUR; //the cost of the laptop is added to the runningTotal variable
			}else if(laptopChoice.equals("5")) {
				System.out.println("Laptop 5 has been added to your subtotal."); //prints that the laptop has been added to their purchase
				runningTotal += LAPTOP_PRICE_FIVE; //the cost of the laptop is added to the runningTotal variable4
			}
			else {
				System.out.println("Not a valid option."); //prints error message to the user
			}
			//asks if the user wants to add the 2 year warranty for an additional cost of $100
			System.out.println("Would you like to add the 2 year protection warranty for an additional $" + WARRANTY_COST + "? [y]es or [n]o: ");
			warrantyChoice = in.next().toLowerCase(); //takes and reads user input as a string and sets it to lowercase
			
			//if the user inputs "y" as their choice, then a message is displayed, otherwise the warranty is not added to the total purchase
			if(warrantyChoice.equals("y")) {
				System.out.println("2 year protection plan has been added to your subtotal."); //tells the user that the warranty has been added to their purchase
				runningTotal += WARRANTY_COST; //the cost of the warranty is added to the runningTotal variable
				warrantyAdded = true; //boolean variable is now set equal to true
			}
			else {
				//warranty is not added to the total purchase for the user
				System.out.println("Warranty will not be added to your total purchase.");
			}
			
			//asks if the user wants to add the wireless mouse for an additional cost of $75
			System.out.println("Would you also like to add the wireless mouse for an additional $" + MOUSE_COST + "? [y]es or [n]o: ");
			mouseChoice = in.next().toLowerCase(); //takes and reads user input as a string and sets it to lowercase
			
			//if the user inputs "y" as their choice, then a message is displayed, otherwise the wireless mouse is not added to the total purchase44
			if(mouseChoice.equals("y")) {
				System.out.println("Wireless mouse has been added to your subtotal."); //tells the user that the wireless mouse has been added to their purchase
				runningTotal += MOUSE_COST; //the cost of the wireless mouse is added to the runningTotal variable
				mouseAdded = true; //boolean variable is set equal to true
			}
			else {
				//wireless mouse is not added to the total purchase for the user
				System.out.println("Wireless mouse will not be added to your total purchase.");
			}
			
			//variable of type double is used to call the laptopPurchase() method and takes the runningTotal as its one parameter
			double totalCost = laptopPurchase(runningTotal);

			//prints a purchase summary or receipt to the user
			System.out.println("\nPurchase Summary:");
			System.out.println("*******************************************");
			System.out.println("Laptop Number: " + laptopChoice); //prints the laptop number that the user purchased
			System.out.println("2 Year Warranty Added: " + warrantyAdded); //prints either true or false if the user added the 2 year warranty to their total purchase
			System.out.println("Wireless Mouse Added: " + mouseAdded); //prints either true or false if the user added the wireless mouse to their total purchase
			System.out.printf("Total (includes tax & shipping): $%.2f\n", totalCost); //prints the total cost that includes the tax & shipping costs & is formatted to 2 decimal places
			System.out.println("*******************************************");
			
			System.out.println("\nWould you like to purchase another laptop? [y]es or [n]o: "); //prints message to the user asking if they want to continue
			programExit = in.next().toLowerCase(); //takes and reads user input as a string and sets the input to lower case
		}
		//prints message to the user once the program has ended
		System.out.println("\nYou have exited the program. Thank you and have a great day!");
		
		in.close();
	}
	
	/**
	 * Method of return type double and takes one parameter
	 * Method calculates the shipping cost and tax cost based off their constant tax and shipping rates and adds it the the total purchase value
	 * @param items of data type double represents the total value of all the purchased items from the user that includes the laptop, mouse, and/or warranty
	 * Returns the total purchase for the user as a double 
	 */
	public static double laptopPurchase(double items) {
		
		//2 constant double variables that each represent that constant rates for the tax and shipping
		final double TAX_RATE = 0.07;
		final double SHIPPING_RATE = 0.10;
		
		//3 double variables are declared and initialized to zero
		double itemsTax = 0.0;
		double shippingCost = 0.0;
		double purchaseTotal = 0.0;
		
		itemsTax = TAX_RATE * items; //calculates the tax cost by multiplying the tax rate times the value of all the items from the user
		shippingCost = SHIPPING_RATE * items; //calculates the shipping cost by multiplying the shipping rate times the value of all the items from the user
		purchaseTotal = items + itemsTax + shippingCost; //the purchase total is calculated by adding the values of the items from the user plus the tax cost and shipping cost
		
		//if the total value of all the items are less than or equal to zero then it will return zero
		if(items <= 0) {
			return 0;
		}
		return purchaseTotal; //returns the total purchase as a double
	}
}
