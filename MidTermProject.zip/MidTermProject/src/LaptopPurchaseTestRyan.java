import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
/**  
* Abhishek Ryan - aryan9  
* CIS171 22149
* Feb 25, 2022  
*/
class LaptopPurchaseTestRyan {
	
	@Test
	void testLaptopPurchase() {
		
		//asserts for only the base price of the laptop
	    assertEquals(1871.9883, LaptopPurchaseRyan.laptopPurchase(1599.99), 0.01);
		assertEquals(935.9883, LaptopPurchaseRyan.laptopPurchase(799.99), 0.01);
		assertEquals(1052.9883, LaptopPurchaseRyan.laptopPurchase(899.99), 0.01);
		assertEquals(1813.4883, LaptopPurchaseRyan.laptopPurchase(1549.99), 0.01);
		assertEquals(2690.9882, LaptopPurchaseRyan.laptopPurchase(2299.99), 0.01);
		
		//asserts for both the added costs of the wireless mouse and the warranty
		assertEquals(2076.7149, LaptopPurchaseRyan.laptopPurchase(1774.97), 0.01);
		assertEquals(1140.7149, LaptopPurchaseRyan.laptopPurchase(974.97), 0.01);
		assertEquals(1257.7149, LaptopPurchaseRyan.laptopPurchase(1074.97), 0.01);
		assertEquals(2018.2149, LaptopPurchaseRyan.laptopPurchase(1724.97), 0.01);
		assertEquals(2895.7149, LaptopPurchaseRyan.laptopPurchase(2474.97), 0.01);
		
		//asserts only with the added wireless mouse cost
		assertEquals(1959.7266, LaptopPurchaseRyan.laptopPurchase(1674.98), 0.01);
		assertEquals(1023.7266, LaptopPurchaseRyan.laptopPurchase(874.98), 0.01);
		assertEquals(1140.7266, LaptopPurchaseRyan.laptopPurchase(974.98), 0.01);
		assertEquals(1901.2266, LaptopPurchaseRyan.laptopPurchase(1624.98), 0.01);
		assertEquals(2778.7266, LaptopPurchaseRyan.laptopPurchase(2374.98), 0.01);
		
		//asserts only with the added warranty cost
		assertEquals(1988.9766, LaptopPurchaseRyan.laptopPurchase(1699.98), 0.01);
		assertEquals(1052.9766, LaptopPurchaseRyan.laptopPurchase(899.98), 0.01);
		assertEquals(1169.9766, LaptopPurchaseRyan.laptopPurchase(999.98), 0.01);
		assertEquals(1930.4766, LaptopPurchaseRyan.laptopPurchase(1649.98), 0.01);
		assertEquals(2807.9766, LaptopPurchaseRyan.laptopPurchase(2399.98), 0.01);
		
		assertEquals(0, LaptopPurchaseRyan.laptopPurchase(-1), 0.01); //asserts for a negative value
	}
}
